<?php get_header(); ?>

<main>

<section class="hero">
    <div class="wrap hero-grid">

        <div>
            <div class="eyebrow">
                DIGITAL GROWTH AGENCY
            </div>

            <h1>
                We Build Digital
                <span>Experiences</span>
                That Grow Businesses
            </h1>

            <p>
                We help businesses grow online with professional
                web development, e-commerce, SEO and digital marketing.
            </p>

            <div class="hero-buttons">
                <a class="btn" href="<?php echo home_url('/contact/'); ?>">
                    Get a Free Quote
                </a>

                <a class="btn alt" href="<?php echo home_url('/portfolio/'); ?>">
                    View Our Work
                </a>
            </div>

            <div class="hero-points">
                <span>✓ Result Focused</span>
                <span>✓ Experienced Team</span>
                <span>✓ Business Growth</span>
            </div>
        </div>


        <div class="hero-visual">

            <div class="growth-card">

                <div class="growth-top">
                    <span>Business Growth</span>
                    <strong>+86%</strong>
                </div>

                <div class="chart">
                    <div class="bar b1"></div>
                    <div class="bar b2"></div>
                    <div class="bar b3"></div>
                    <div class="bar b4"></div>
                    <div class="bar b5"></div>
                    <div class="bar b6"></div>
                </div>

                <div class="growth-bottom">

                    <div>
                        <small>Visitors</small>
                        <strong>48.6K</strong>
                    </div>

                    <div>
                        <small>Leads</small>
                        <strong>2.8K</strong>
                    </div>

                    <div>
                        <small>Sales</small>
                        <strong>1.4K</strong>
                    </div>

                </div>

            </div>

        </div>

    </div>
</section>


<section class="trust-section">

    <div class="wrap">

        <p class="trust-title">
            Helping businesses build a stronger digital presence
        </p>

        <div class="trust-items">
            <span>STARTUPS</span>
            <span>E-COMMERCE</span>
            <span>SMALL BUSINESS</span>
            <span>ENTERPRISE</span>
            <span>AGENCIES</span>
        </div>

    </div>

</section>


<section class="section">

    <div class="wrap">

        <div class="head">

            <div class="eyebrow">
                OUR SERVICES
            </div>

            <h2>
                Everything You Need To
                <span>Grow Online</span>
            </h2>

            <p>
                Complete digital solutions from strategy and
                development to marketing and optimization.
            </p>

        </div>


        <div class="cards">

            <div class="card">
                <div class="service-icon">💻</div>

                <h3>Web Development</h3>

                <p>
                    Professional responsive websites designed
                    to represent your business.
                </p>

                <a href="<?php echo home_url('/wordpress-development/'); ?>">
                    Explore Service →
                </a>
            </div>


            <div class="card">
                <div class="service-icon">🛒</div>

                <h3>E-Commerce</h3>

                <p>
                    Powerful online stores designed for
                    products and online sales.
                </p>

                <a href="<?php echo home_url('/woocommerce/'); ?>">
                    Explore Service →
                </a>
            </div>


            <div class="card">
                <div class="service-icon">🔎</div>

                <h3>SEO</h3>

                <p>
                    SEO strategies to improve search visibility
                    and organic traffic.
                </p>

                <a href="<?php echo home_url('/seo/'); ?>">
                    Explore Service →
                </a>
            </div>


            <div class="card">
                <div class="service-icon">📈</div>

                <h3>Google Ads</h3>

                <p>
                    Performance-focused advertising campaigns
                    built around business goals.
                </p>

                <a href="<?php echo home_url('/google-ads/'); ?>">
                    Explore Service →
                </a>
            </div>


            <div class="card">
                <div class="service-icon">📱</div>

                <h3>Social Ads</h3>

                <p>
                    Targeted social media campaigns designed
                    to generate leads.
                </p>

                <a href="<?php echo home_url('/facebook-ads/'); ?>">
                    Explore Service →
                </a>
            </div>


            <div class="card">
                <div class="service-icon">⚙️</div>

                <h3>WordPress</h3>

                <p>
                    Custom WordPress development, optimization
                    and maintenance.
                </p>

                <a href="<?php echo home_url('/wordpress/'); ?>">
                    Explore Service →
                </a>
            </div>

        </div>

    </div>

</section>


<section class="cta">

    <div class="wrap">

        <div class="eyebrow">
            LET'S WORK TOGETHER
        </div>

        <h2>
            Ready To Grow Your Business?
        </h2>

        <p>
            Tell us about your project and let's create
            a professional digital experience.
        </p>

        <a class="btn" href="<?php echo home_url('/contact/'); ?>">
            Get A Free Quote
        </a>

    </div>

</section>

</main>

<?php get_footer(); ?>